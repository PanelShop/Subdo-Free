addSubDomain({
    description: 'A website to generate code screenshots', 
    domain: 'is-an.app', 
    subdomain: 'gravity', 
    owner: {
      email: 'hariskumar.eth@gmail.com',
    },
    record: {
      CNAME: 'cname.vercel-dns.com', 
    },
   
  })