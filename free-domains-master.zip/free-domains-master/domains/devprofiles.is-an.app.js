addSubDomain({
  description: 'list of devevlopers profiles',
  domain: 'is-an.app',
  subdomain: 'devprofiles',
  owner: {
    email: 'oyepriyansh@hotmail.com',
    repo: 'https://github.com/oyepriyansh/DevProfiles',
  },
  record: {
    CNAME: 'cname.vercel-dns.com'
  },
  proxy: false
});
