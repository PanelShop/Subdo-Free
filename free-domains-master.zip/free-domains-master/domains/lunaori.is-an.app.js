addSubDomain({
  description: "Lunaori is an app by a weeb developer for weeb developers",
  domain: "is-an.app",
  subdomain: "lunaori",
  owner: {
    repo: "",
    email: "orekidev@gmail.com",
  },
  record: {
    CNAME: "cname.vercel-dns.com",
  },
  proxy: false,
});
