addSubDomain({
  description: 'A website for my vercel bot',
  domain: 'is-an.app',
  subdomain: 'cat',
  owner: {
    email: 'wqwdrrovb@mozmail.com',
  },
  record: {
    CNAME: 'cname.vercel-dns.com'
  },
  proxy: false
})
