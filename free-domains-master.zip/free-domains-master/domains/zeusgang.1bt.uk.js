addSubDomain({
  description: 'A simple website that shows member information and leaderboards for the minecraft team',
  domain: '1bt.uk',
  subdomain: 'zeusgang',
  owner: {
    repo: 'https://github.com/zeusgangproject/zeusgangproject.github.io',
  },
  record: {
    CNAME: 'zeusgangproject.github.io',
  },
})
