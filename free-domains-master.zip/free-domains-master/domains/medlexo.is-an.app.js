addSubDomain({
  description: 'Free video toolbox for videographer or video editor',
  domain: 'is-an.app',
  subdomain: 'medlexo',
  owner: {
    email: 'medlexopm@gmail.com',
  },
  record: {
    A: [
      '185.27.134.137',
    ],
  },
})
