addSubDomain({
  description: 'A funny game !',
  domain: 'is-an.app',
  subdomain: 'morpion',
  owner: {
    repo: 'https://github.com/Nonolanlan1007/morpion',
    email: 'nolhan.dev@gmail.com',
  },
  record: {
    CNAME: 'nonolanlan1007.github.io',
  },
  proxy: false,
})
