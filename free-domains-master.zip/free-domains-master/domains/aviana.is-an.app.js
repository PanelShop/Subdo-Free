addSubDomain({
  description: 'A website for my discord bot',
  domain: 'is-an.app',
  subdomain: 'aviana',
  owner: {
    email: 'contact@exylium.tk',
  },
  record: {
    CNAME: 'cname.vercel-dns.com'
  },
  proxy: false
});
