addSubDomain({
  description: 'DOM Manipulation Simplified',
  domain: '1bt.uk', 
  subdomain: 'domjs',
  owner: {
    repo: 'https://github.com/SX-9/dom.js',
    email: 'sx-91@outlook.com',
  },
  record: {
    CNAME: 'sx-9.github.io',
  },
});
